/**
 * @file student.h
 * @author Gregory Archer (archeg1@mcmaster.ca)
 * @brief 
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */
 
 /**
  * @brief Student type stores a student with fields first_name, last_name, id, *grades, and  num_grades
  * 
  */
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

/**
 * @brief Function declaration for add_grade in student.c
 * 
 * @param student 
 * @param grade 
 */
void add_grade(Student *student, double grade);
/**
 * @brief Function declaration for average in student.c
 * 
 * @param student 
 * @return double 
 */
double average(Student *student);
/**
 * @brief Function declaration for print_student in student.c
 * 
 * @param student 
 */
void print_student(Student *student);
/**
 * @brief Function declaration for generate_random_student in student.c
 * 
 * @param grades 
 * @return Student* 
 */
Student* generate_random_student(int grades); 
