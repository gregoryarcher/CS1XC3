/**
 * @file course.c
 * @author Gregory Archer (archeg1@mcmaster.ca)
 * @brief 
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief Adds a new student (of Student type) to course (of Course type), by reallocating space in
 *        course for the additional student
 * 
 * @param course 
 * @param student 
 * @return nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student)); // creates space for one student in the course
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); // reallocates necessary space for number of students enrolled
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief Prints out all the attributes of the course (Name, Code, Total Students)
 *        Prints out a separator of "*" characters
 *        Prints the name of each student of the course
 * 
 * @param course
 * @return nothing 
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief Iterates through the students in the course and returns the student with the highest student_average 
 * 
 * @param course 
 * @return Student* 
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++) // iterates through the students in the course
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average)  // changes which student has the highest average
    {
      max_average = student_average; 
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief Iterates through the students of the courses and adds students to a list if they are passing the course,
 *        Returns the list.
 * 
 * @param course 
 * @param total_passing 
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) // iterating through the students of the course & counting how many have average above 50%
    if (average(&course->students[i]) >= 50) count++; 
  
  passing = calloc(count, sizeof(Student)); // allocating the neccessary amount of space for students passing the course

  int j = 0;
  for (int i = 0; i < course->total_students; i++)  // iterating through the student of the course & checking if the given student is passing the course
  {
    if (average(&course->students[i]) >= 50) 
    {
      passing[j] = course->students[i]; // if student is passing, append them to the list of passing students
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}