/**
 * @file course.h
 * @author Gregory Archer (archeg1@mcmaster.ca)
 * @brief 
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "student.h"
#include <stdbool.h>

/**
 * @brief Course type stores a course with fields name, code, *students, and total_students
 * 
 */
typedef struct _course 
{
  char name[100]; /**< the name of the course */
  char code[10]; /**< the code of the course */
  Student *students; /**< points to the students in the course */
  int total_students; /**< total number of students in course */
} Course;

/**
 * @brief Function declaration for enroll_student in course.c
 * 
 * @param course 
 * @param student 
 */
void enroll_student(Course *course, Student *student);
/**
 * @brief Function declaration for print_course in course.c
 * 
 * @param course 
 */
void print_course(Course *course);
/**
 * @brief Function declaration for *top_student in course.c
 * 
 * @param course 
 * @return Student* 
 */
Student *top_student(Course* course);
/**
 * @brief Function declaration for *passing in course.c
 * 
 * @param course 
 * @param total_passing 
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing);


